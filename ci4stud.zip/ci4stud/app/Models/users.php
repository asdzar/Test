<?php namespace App\Models;
use CodeIgniter\Model;

class users extends Model
{
	public function get_login($username, $password)
	{
     $username = 'aing';
     $password = '12345678';
	}

	//--------------------------------------------------------------------

}