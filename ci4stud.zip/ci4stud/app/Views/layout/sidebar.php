<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	        </button>
        </div>
	  		<div class="img bg-wrap text-center py-4" style="background-image: url(images/ui5.jpg);">
	  			<div class="user-logo">
	  				<div class="img" style="background-image: url(ic/user.png);"></div>
	  				<h3>Username</h3>
	  			</div>
	  		</div>
        <ul class="list-unstyled components mb-5">
          <li class="active">
            <a href="/"><span class="fa fa-home mr-3"></span>Dashboard</a>
          </li>
          <li class="dropdown active">
            <a class="dropdown-toggle" data-bs-toggle="dropdown" href="#"><span class="fa fa-clipboard mr-3"></span>Product</a>
            <ul class="dropdown-menu animated fadeInLeft" role="menu">
              <li class="dropdown-item active">
                <a href="#"><span class="fa fa-shopping-bag mr-3"></span>Kategori Barang</a>
              </li>
              <li class="dropdown-item">
                <a href="#"><span class="fa fa-shopping-bag mr-3"></span>Input Barang</a>
              </li>
              <li class="dropdown-item">
                <a href="#"><span class="fa fa-shopping-bag mr-3"></span>Output Barang</a>
              </li>
            </ul>
          </li>
          <li class="active">
            <a href="#"><span class="fa fa-shopping-bag mr-3"></span>Transaksi</a>
          </li>
          <li class="active">
            <a href="#"><span class="fa fa-book mr-3"></span>Laporan</a>
          </li>
          <li class="active">
            <a href="#"><span class="fa fa-user-plus mr-3"></span>Tambah User</a>
          </li>
          <li class="active">
            <a href="#"><span class="fa fa-sign-out mr-3"></span>Keluar</a>
          </li>
        </ul>
</nav>